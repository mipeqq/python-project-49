### Hexlet tests and linter status:
[![Actions Status](https://github.com/mipeqq/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/mipeqq/python-project-49/actions)

Asciinema для brain-even: https://asciinema.org/a/1pLZYO6e0ViC227kYXjk15WYp

Asciinema для brain-calc: https://asciinema.org/a/5WfMXnmrrm0sFYkJe2NrhCSYf

Asciinema для brain-gcd: https://asciinema.org/a/iIHjbQz7EJwgng1iJjWzJPNih

Asciinema для brain-progression: https://asciinema.org/a/WVHaT3klnE4dwKmvdDKc53FIc